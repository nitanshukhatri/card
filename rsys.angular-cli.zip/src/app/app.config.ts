export const Config = {
    apiEndpoint: 'http://localhost:4200/assets/showcase/data/'
}